import React from "react";
import './Quote.css'

function Quote(){

return(<>
<div className="Quote">
<div>
<h1>
    Quote of the Day
 </h1>
 <p>
    Time is Precious So use is wisely 
 </p>
</div>
</div>

</>)

}

export default Quote;